/* tslint:disable */
/* eslint-disable */

/**
 * Owned terrain-only components and evidence for the supplied boundary spans.
 * Labels remain valid after the source analysis is freed or its obstacle mode changes.
 */
export class AreaSnapshot {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Returns an owned row-major Uint32Array: zero for blocked terrain, positive component IDs
     * for every original walkable cell. Spans remove graph crossings, not cells.
     */
    labels(): Uint32Array;
    /**
     * Per-component cell counts and per-input-span effects with all supplied cuts applied.
     * A separating edge count is not evidence that this span alone disconnects the terrain.
     */
    metadataJson(): string;
}

/**
 * Incremental terrain-only topology. Owns its grid; dropping/freeing cancels unfinished work.
 */
export class BaseTopologyJob {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Prepares clearance or executes one origin/consolidation pass. No hard CPU-time budget.
     * Returns completion status; completed jobs can be advanced again without changing results.
     */
    advance(): boolean;
    /**
     * Owned final labels; errors before successful completion, including after any failed step.
     */
    labels(): Uint32Array;
    metadataJson(): string;
    progressJson(): string;
}

/**
 * A SC:R install's CASC storage, read through host-provided file callbacks. Pass it to
 * `MapRenderer.loadAssets` in place of the `requiredAssets`/`addAsset` prefetch.
 *
 * `files` provides sync access to the install directory (the one containing `.build.info`).
 * Paths are relative to it and use `/` separators:
 *
 * - `open(path)`: opens a file for reading and returns any handle value; throws if it can't.
 * - `size(handle)`: the file's length in bytes.
 * - `read(handle, buffer, position)`: reads up to `buffer.length` bytes at `position` into the
 *   `Uint8Array` `buffer`, returning how many were read (0 only at end of file).
 * - `close(handle)`: closes a handle `open` returned.
 * - `listDir(path)`: the names of the entries in a directory, or `[]` if it doesn't exist.
 *
 * In Node these map one to one onto `fs.openSync`, `fs.fstatSync(fd).size`, `fs.readSync`,
 * `fs.closeSync` and `fs.readdirSync`. Every callback is called with `files` as `this`.
 *
 * `options` is an optional JSON object: `{ "cacheBytes": 134217728 }` bounds the shared cache
 * of decoded assets (least recently used are evicted first; 0 disables caching).
 *
 * Data archives stay open until the storage is freed (`free()`).
 */
export class CascStorage {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Opens the storage, reading the install's build info, indices, encoding table and root
     * catalog (a few MB). Throws if `files` lacks a callback or the directory isn't a readable
     * SC:R install.
     */
    constructor(files: any, options?: string | null);
    /**
     * The total size of the decoded assets currently cached.
     */
    readonly cachedBytes: number;
    /**
     * The install's game version from its build info (e.g. `"1.23.10.13515"`), if recorded.
     * Useful in cache keys for rendered images, since a game patch can change the assets.
     */
    readonly version: string | undefined;
}

/**
 * A parsed map plus the assets fed to it so far. See the module docs for the prefetch/render
 * flow.
 */
export class MapRenderer {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Feeds one fetched asset back in, keyed by the CASC path `requiredAssets`/
     * `requiredGraphics` returned. Unknown paths are an error (they'd silently never be read).
     */
    addAsset(casc_path: string, bytes: Uint8Array): void;
    /**
     * Resolves terrain and initial static melee obstacles from UNIT/THG2.
     * Caller-supplied units.dat defines collision bounds; no artwork is needed.
     * Neutral buildings and resources block routes by default. This is a conservative
     * 8-pixel approximation, not a simulation of moving units or destruction. Missing UNIT
     * or THG2 chunks contribute no objects. Their parsers are permissive: incomplete trailing
     * records are ignored, and obstacleCount is not a map-integrity check.
     */
    analyzeMap(cv5: Uint8Array, vf4: Uint8Array, units: Uint8Array): TerrainAnalysis;
    /**
     * Resolves terrain without loading any artwork or unit data. The returned snapshot
     * owns its grid and remains valid independently of this renderer and its asset cache.
     * Missing tile references and incomplete table records are errors: analysis must not
     * silently turn absent terrain metadata into traversable ground.
     */
    analyzeTerrain(cv5: Uint8Array, vf4: Uint8Array): TerrainAnalysis;
    /**
     * Loads every asset a render under `options` needs straight from `storage`, in place of
     * the `requiredAssets`/`requiredGraphics`/`addAsset` prefetch. Returns the CASC paths of
     * art assets the install doesn't have: those drawables degrade and the render still
     * succeeds. Throws if a base asset (tileset or `.dat` table) is missing or any read fails.
     */
    loadAssets(storage: CascStorage, options: string): string[];
    /**
     * Renders the zero-asset minimap and encodes it as a PNG.
     */
    minimapPng(options: string): Uint8Array;
    /**
     * Renders the zero-asset minimap to RGBA pixels. Needs no assets at all; if round 1's
     * `.dat` tables happen to be loaded they refine dot sizing and melee filtering.
     */
    minimapRgba(options: string): RenderedImage;
    /**
     * Parses a `.scm`/`.scx` map file (MPQ + CHK).
     */
    constructor(map_bytes: Uint8Array);
    /**
     * Builds the render plan (the decide/draw split — see `broodmap-render`'s `plan` module)
     * as JSON, for external executors like a GPU renderer. Requires round 1's assets.
     */
    planJson(options: string): string;
    /**
     * Renders the map preview and encodes it as a PNG.
     */
    renderPng(options: string): Uint8Array;
    /**
     * Renders the map preview to RGBA pixels.
     */
    renderRgba(options: string): RenderedImage;
    /**
     * The CV5 and VF4 paths, in that order. Fetch these and pass their bytes to
     * `analyzeTerrain`; they do not need to be registered with `addAsset`.
     */
    requiredAnalysisAssets(): string[];
    /**
     * Round 1 of the prefetch: the CASC paths of the base assets (tileset tables + `.dat`
     * tables) this map needs under `options`. Fetch and [`add_asset`](Self::add_asset) all of
     * them before calling [`required_graphics`](Self::required_graphics).
     */
    requiredAssets(options: string): string[];
    /**
     * Round 2 of the prefetch: the CASC paths of the art assets (anims, SD canvas GRPs) the
     * map's units and sprites need under `options`. Requires round 1's tables to already be
     * added. A path that fails to fetch can simply be skipped — that one drawable degrades,
     * the render still succeeds.
     */
    requiredGraphics(options: string): string[];
    /**
     * CV5, VF4, and units.dat, in that order, for `analyzeMap`.
     */
    requiredMapAnalysisAssets(): string[];
    /**
     * Map height in tiles (0 if the map has no readable terrain).
     */
    readonly heightTiles: number;
    /**
     * Map width in tiles (0 if the map has no readable terrain).
     */
    readonly widthTiles: number;
}

/**
 * An immutable region result detached from its source [`TerrainAnalysis`] snapshot.
 *
 * Labels are row-major 8-pixel walk cells. Zero denotes blocked terrain; positive labels are
 * one-based region IDs. Passages describe one representative connection per adjacent region pair.
 */
export class RegionSnapshot {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Returns an independently owned row-major `Uint32Array` of region labels.
     *
     * Zero is blocked terrain; region IDs begin at one and correspond to `metadataJson` entries.
     */
    labels(): Uint32Array;
    /**
     * Serializes compact region and passage metadata, without duplicating the full label buffer.
     */
    metadataJson(): string;
}

/**
 * A rendered RGBA image, ready for `new ImageData(new Uint8ClampedArray(data), width, height)`.
 */
export class RenderedImage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The RGBA8 pixels, row-major (copies out of WASM memory).
     */
    readonly data: Uint8Array;
    readonly height: number;
    /**
     * Non-fatal notes about things the render skipped.
     */
    readonly warnings: string[];
    readonly width: number;
}

/**
 * An 8-pixel point-movement snapshot, optionally including initial static melee obstacles.
 * Moving units and mover size are not represented. This does not certify engine pathing or walls.
 */
export class TerrainAnalysis {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Computes clearance-derived regions for the currently active terrain/obstacle grid.
     *
     * `minProminencePixels` must be from 8 through 4096. An omitted
     * `minRelativeProminencePercent` uses the core default of 40; supplied values must be from 0
     * through 100. The returned result owns its labels and metadata, so it remains valid after
     * this analysis snapshot is freed or its obstacle toggle changes. Regions are a static
     * square-clearance graph, not unit-fit or engine pathing data.
     */
    analyzeRegions(min_prominence_pixels: number, min_relative_prominence_percent?: number | null): RegionSnapshot;
    /**
     * Ground and air distances between the selected candidates' near-center walk anchors.
     * Respects the current obstacle toggle. Hypothetical depots are not added as obstacles.
     * Disconnected bases return null ground distance; undiscovered/out-of-range IDs are errors.
     */
    baseRouteJson(start_id: number, end_id: number): string;
    /**
     * Starts reusable map-wide analysis from JSON [{id,routeAnchor:[walkX,walkY]|null}].
     * At most 256 unique IDs and 32KiB JSON. Uses terrain alone, independent of obstacle mode.
     * A missing routeAnchor is skipped like null. Advance between event-loop yields;
     * completion is required for results.
     */
    beginBaseTopology(bases_json: string, min_widening_percent?: number | null): BaseTopologyJob;
    /**
     * Row-major bytes: bit 0 walkable, bit 1 CV5 terrain-buildability hint,
     * bit 2 ramp, bits 3..4 minitile elevation (0..2), bit 5 terrain cell obstructed by a
     * static map object (retained even when objects are ignored). Bit 0 respects the current
     * obstacle toggle. Buildability excludes occupancy,
     * footprint, creep/power, resources, and other placement restrictions.
     */
    cellFlags(): Uint8Array;
    /**
     * Check proposed building rectangles and mover passage in an explicitly bounded pixel window.
     * Uses original terrain plus exact static object rectangles when the obstacle toggle is enabled.
     * Static placement checks omit race rules, power, creep, resource spacing, and dynamic state.
     * A blocked result is local to this window and model, not a certified game wall.
     */
    checkWallJson(query_json: string): string;
    /**
     * Row-major logical-pixel radii of empty, axis-aligned squares centered on walk cells.
     * Blocked cells are zero; walkable cells adjacent to a blocker or map edge are 4px.
     * Values follow the obstacle toggle and include the map boundary. This is a square
     * (Chebyshev) distance measure of the raster, not Euclidean distance, corridor width,
     * or proof that a StarCraft unit can pass. The returned buffer is independently owned.
     */
    clearancePixels(): Uint16Array;
    /**
     * Batches up to 256 terrain-only entrance surveys without rebuilding the immutable terrain
     * preparation. Input is JSON `[[[startX,startY],[endX,endY]], ...]` with strict unsigned
     * integer coordinates and a 32 KiB limit. Results preserve input order and use the same
     * objects returned by `entrancesJson`. Aggregate route output is capped at 2,097,152 points.
     * These limits do not bound CPU time: each distinct origin can require a full-grid search.
     * Callers needing responsive cancellation should submit smaller origin groups and yield
     * between synchronous calls. An empty batch returns `[]` without preparing a survey.
     */
    entrancesBatchJson(queries_json: string, min_widening_percent?: number | null): string;
    /**
     * Finds local width transitions along a clearance-favoring route from start to end.
     *
     * Coordinates are 8-pixel walk cells. This always surveys terrain alone, regardless of the
     * obstacle toggle: resources and neutral objects do not define geological entrances.
     * `minWideningPercent` defaults to 25 and accepts integral values from 0 through 200.
     * Candidate centers lie within the first 1024 logical pixels; profiles may look 192px farther.
     * `outwardSampleCount` is 3 normally, or 2 when a late turn excludes the +160px sample.
     * Cross-section endpoints in the JSON are logical pixels; route points are walk cells. Spans
     * are raster approximations, not certified chokepoints, construction legality, unit fit, or
     * shortest movement routes.
     */
    entrancesJson(start_x: number, start_y: number, end_x: number, end_y: number, min_widening_percent?: number | null): string;
    /**
     * Discovers and caches resource-base candidates in a snapshot made by `analyzeMap`.
     * Options: `{depotWidthTiles:4,depotHeightTiles:3,maxMineralBlockerAmount:8}`.
     * Set maxMineralBlockerAmount to null to disallow clearing; unknown amounts never qualify.
     * allowDestructibleClearing and allowStartObstacleClearing default to true.
     * requiredObstacles lists overlapping buildings requiring destruction; startClearedObstacles
     * lists overlaps removed automatically if that exact start is occupied (including invincible ones).
     * Candidate requiredMinerals lists direct placement prerequisites. All objects remain
     * blockers for current route queries; routeAnchor is null if the whole depot area is blocked.
     * IDs are zero-based in top-to-bottom, left-to-right depot order. Discovery always uses
     * the initial static obstacles, independently of the route toggle. This is a heuristic:
     * stock resource IDs, no creep/power or complete placement rules, and no main/natural roles.
     * Unknown options and unsupported inputs fail without replacing the last successful catalog.
     */
    findBasesJson(options_json: string): string;
    /**
     * Partitions terrain alone using up to 256 finite pixel-coordinate spans.
     *
     * Input is JSON `[[[x1,y1],[x2,y2]], ...]`, at most 32 KiB; coordinates must be
     * nonnegative integers within inclusive map edges, and each span must have distinct ends.
     * An empty list returns ordinary terrain components. This does not mutate routing,
     * the base catalog, or obstacle mode, and does not validate wall placement.
     */
    partitionAreas(spans_json: string): AreaSnapshot;
    /**
     * Two wall-contact spans at the ends of each recognized terrain ramp.
     *
     * Always uses the original terrain, independent of obstacle mode. Positions are walk cells;
     * span endpoints and widths are logical pixels. These are elevation/ramp-flag observations,
     * not route-local widening claims or certified movement/building-placement boundaries.
     */
    rampsJson(): string;
    /**
     * Routes between 8-pixel cell centers. Both endpoints must be walkable; they are
     * never silently moved. Points include both endpoints. Disconnected endpoints return
     * an empty point list and null groundDistancePixels. Distances use logical pixels,
     * independent of preview resolution. Ground costs are 8 / 11.312 pixels per step
     * (fixed-point octile approximation), with no diagonal corner cutting.
     */
    routeJson(start_x: number, start_y: number, end_x: number, end_y: number): string;
    /**
     * Choose object-aware routing or the original terrain-only model. Turning this off
     * ignores every obstacle, including invincible buildings; it does not simulate removal.
     */
    setObstaclesEnabled(enabled: boolean): void;
    /**
     * Starts a bounded, resumable search for static wall layouts. Construction prepares terrain
     * and candidates synchronously, so its bounded preprocessing can still occupy one event-loop turn.
     * The job snapshots the selected
     * terrain/obstacle model, so later obstacle-toggle changes do not affect it.
     */
    startWallSearch(query_json: string): WallSearchJob;
    /**
     * Chooses collision-safe walk-cell-center endpoints around a selected entrance. Search query
     * start/end are placeholders here; the explicit entrance controls the direction.
     */
    suggestWallEndpointsJson(query_json: string, entrance_json: string): string;
    /**
     * Returns terrain-only walk-cell connectivity reachable from an entrance near a bounded
     * pixel window. The result is local to the returned rectangle and ignores objects,
     * buildability, and terrain height.
     */
    wallPlacementReachJson(input_json: string): string;
    /**
     * Conventional melee palette with dimensions from the caller's units.dat. Empty for terrain-only snapshots.
     */
    wallProfilesJson(): string;
    readonly heightWalkTiles: number;
    /**
     * Number of static obstacle rectangles identified in this snapshot.
     */
    readonly obstacleCount: number;
    readonly widthWalkTiles: number;
}

/**
 * Incremental bounded wall search. It owns the core search snapshot, so it can safely outlive
 * its TerrainAnalysis creator. Dropping/freeing it abandons unfinished work.
 */
export class WallSearchJob {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Serializes the completed result. Calling this before a terminal step is an error so callers
     * do not accidentally copy route data while reporting progress.
     */
    resultJson(): string;
    /**
     * Advances at most 16 search states. Call between browser event-loop yields.
     * Returns true when a terminal result is available.
     */
    step(max_states: number): boolean;
    readonly exploredStates: number;
    readonly layoutCount: number;
}

/**
 * Summarizes a map file's scenario as JSON (see the README for the fields). `options` is an
 * optional JSON object raising (or lowering) broodmap's default resource limits:
 * `{ "maxMapBytes", "maxMpqFileBytes", "maxChkBytes", "maxMergedChunkBytes" }`. Fails if the file
 * isn't a readable map within those limits, or lacks the scenario name, player or force sections
 * every playable map has.
 */
export function summarizeMapJson(map_bytes: Uint8Array, options?: string | null): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_areasnapshot_free: (a: number, b: number) => void;
    readonly __wbg_basetopologyjob_free: (a: number, b: number) => void;
    readonly __wbg_cascstorage_free: (a: number, b: number) => void;
    readonly __wbg_maprenderer_free: (a: number, b: number) => void;
    readonly __wbg_regionsnapshot_free: (a: number, b: number) => void;
    readonly __wbg_renderedimage_free: (a: number, b: number) => void;
    readonly __wbg_terrainanalysis_free: (a: number, b: number) => void;
    readonly __wbg_wallsearchjob_free: (a: number, b: number) => void;
    readonly areasnapshot_labels: (a: number) => [number, number];
    readonly areasnapshot_metadataJson: (a: number) => [number, number, number, number];
    readonly basetopologyjob_advance: (a: number) => [number, number, number];
    readonly basetopologyjob_labels: (a: number) => [number, number, number, number];
    readonly basetopologyjob_metadataJson: (a: number) => [number, number, number, number];
    readonly basetopologyjob_progressJson: (a: number) => [number, number, number, number];
    readonly cascstorage_cachedBytes: (a: number) => number;
    readonly cascstorage_new: (a: any, b: number, c: number) => [number, number, number];
    readonly cascstorage_version: (a: number) => [number, number];
    readonly maprenderer_addAsset: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly maprenderer_analyzeMap: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly maprenderer_analyzeTerrain: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly maprenderer_heightTiles: (a: number) => number;
    readonly maprenderer_loadAssets: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly maprenderer_minimapPng: (a: number, b: number, c: number) => [number, number, number, number];
    readonly maprenderer_minimapRgba: (a: number, b: number, c: number) => [number, number, number];
    readonly maprenderer_new: (a: number, b: number) => [number, number, number];
    readonly maprenderer_planJson: (a: number, b: number, c: number) => [number, number, number, number];
    readonly maprenderer_renderPng: (a: number, b: number, c: number) => [number, number, number, number];
    readonly maprenderer_renderRgba: (a: number, b: number, c: number) => [number, number, number];
    readonly maprenderer_requiredAnalysisAssets: (a: number) => [number, number];
    readonly maprenderer_requiredAssets: (a: number, b: number, c: number) => [number, number, number, number];
    readonly maprenderer_requiredGraphics: (a: number, b: number, c: number) => [number, number, number, number];
    readonly maprenderer_requiredMapAnalysisAssets: (a: number) => [number, number];
    readonly maprenderer_widthTiles: (a: number) => number;
    readonly regionsnapshot_labels: (a: number) => [number, number];
    readonly regionsnapshot_metadataJson: (a: number) => [number, number, number, number];
    readonly renderedimage_data: (a: number) => [number, number];
    readonly renderedimage_height: (a: number) => number;
    readonly renderedimage_warnings: (a: number) => [number, number];
    readonly renderedimage_width: (a: number) => number;
    readonly summarizeMapJson: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly terrainanalysis_analyzeRegions: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly terrainanalysis_baseRouteJson: (a: number, b: number, c: number) => [number, number, number, number];
    readonly terrainanalysis_beginBaseTopology: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly terrainanalysis_cellFlags: (a: number) => [number, number];
    readonly terrainanalysis_checkWallJson: (a: number, b: number, c: number) => [number, number, number, number];
    readonly terrainanalysis_clearancePixels: (a: number) => [number, number];
    readonly terrainanalysis_entrancesBatchJson: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly terrainanalysis_entrancesJson: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly terrainanalysis_findBasesJson: (a: number, b: number, c: number) => [number, number, number, number];
    readonly terrainanalysis_heightWalkTiles: (a: number) => number;
    readonly terrainanalysis_obstacleCount: (a: number) => number;
    readonly terrainanalysis_partitionAreas: (a: number, b: number, c: number) => [number, number, number];
    readonly terrainanalysis_rampsJson: (a: number) => [number, number, number, number];
    readonly terrainanalysis_routeJson: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly terrainanalysis_setObstaclesEnabled: (a: number, b: number) => void;
    readonly terrainanalysis_startWallSearch: (a: number, b: number, c: number) => [number, number, number];
    readonly terrainanalysis_suggestWallEndpointsJson: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly terrainanalysis_wallPlacementReachJson: (a: number, b: number, c: number) => [number, number, number, number];
    readonly terrainanalysis_wallProfilesJson: (a: number) => [number, number, number, number];
    readonly terrainanalysis_widthWalkTiles: (a: number) => number;
    readonly wallsearchjob_exploredStates: (a: number) => number;
    readonly wallsearchjob_layoutCount: (a: number) => number;
    readonly wallsearchjob_resultJson: (a: number) => [number, number, number, number];
    readonly wallsearchjob_step: (a: number, b: number) => [number, number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
