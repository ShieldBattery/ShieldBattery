/* @ts-self-types="./broodmap_wasm.d.ts" */

/**
 * Owned terrain-only components and evidence for the supplied boundary spans.
 * Labels remain valid after the source analysis is freed or its obstacle mode changes.
 */
export class AreaSnapshot {
    static __wrap(ptr) {
        const obj = Object.create(AreaSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        AreaSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AreaSnapshotFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_areasnapshot_free(ptr, 0);
    }
    /**
     * Returns an owned row-major Uint32Array: zero for blocked terrain, positive component IDs
     * for every original walkable cell. Spans remove graph crossings, not cells.
     * @returns {Uint32Array}
     */
    labels() {
        const ret = wasm.areasnapshot_labels(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Per-component cell counts and per-input-span effects with all supplied cuts applied.
     * A separating edge count is not evidence that this span alone disconnects the terrain.
     * @returns {string}
     */
    metadataJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.areasnapshot_metadataJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
}
if (Symbol.dispose) AreaSnapshot.prototype[Symbol.dispose] = AreaSnapshot.prototype.free;

/**
 * Incremental terrain-only topology. Owns its grid; dropping/freeing cancels unfinished work.
 */
export class BaseTopologyJob {
    static __wrap(ptr) {
        const obj = Object.create(BaseTopologyJob.prototype);
        obj.__wbg_ptr = ptr;
        BaseTopologyJobFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BaseTopologyJobFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_basetopologyjob_free(ptr, 0);
    }
    /**
     * Prepares clearance or executes one origin/consolidation pass. No hard CPU-time budget.
     * Returns completion status; completed jobs can be advanced again without changing results.
     * @returns {boolean}
     */
    advance() {
        const ret = wasm.basetopologyjob_advance(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Owned final labels; errors before successful completion, including after any failed step.
     * @returns {Uint32Array}
     */
    labels() {
        const ret = wasm.basetopologyjob_labels(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {string}
     */
    metadataJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.basetopologyjob_metadataJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    progressJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.basetopologyjob_progressJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
}
if (Symbol.dispose) BaseTopologyJob.prototype[Symbol.dispose] = BaseTopologyJob.prototype.free;

/**
 * A parsed map plus the assets fed to it so far. See the module docs for the prefetch/render
 * flow.
 */
export class MapRenderer {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MapRendererFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_maprenderer_free(ptr, 0);
    }
    /**
     * Feeds one fetched asset back in, keyed by the CASC path `requiredAssets`/
     * `requiredGraphics` returned. Unknown paths are an error (they'd silently never be read).
     * @param {string} casc_path
     * @param {Uint8Array} bytes
     */
    addAsset(casc_path, bytes) {
        const ptr0 = passStringToWasm0(casc_path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_addAsset(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Resolves terrain and initial static melee obstacles from UNIT/THG2.
     * Caller-supplied units.dat defines collision bounds; no artwork is needed.
     * Neutral buildings and resources block routes by default. This is a conservative
     * 8-pixel approximation, not a simulation of moving units or destruction. Missing UNIT
     * or THG2 chunks contribute no objects. Their parsers are permissive: incomplete trailing
     * records are ignored, and obstacleCount is not a map-integrity check.
     * @param {Uint8Array} cv5
     * @param {Uint8Array} vf4
     * @param {Uint8Array} units
     * @returns {TerrainAnalysis}
     */
    analyzeMap(cv5, vf4, units) {
        const ptr0 = passArray8ToWasm0(cv5, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(vf4, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(units, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_analyzeMap(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TerrainAnalysis.__wrap(ret[0]);
    }
    /**
     * Resolves terrain without loading any artwork or unit data. The returned snapshot
     * owns its grid and remains valid independently of this renderer and its asset cache.
     * Missing tile references and incomplete table records are errors: analysis must not
     * silently turn absent terrain metadata into traversable ground.
     * @param {Uint8Array} cv5
     * @param {Uint8Array} vf4
     * @returns {TerrainAnalysis}
     */
    analyzeTerrain(cv5, vf4) {
        const ptr0 = passArray8ToWasm0(cv5, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(vf4, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_analyzeTerrain(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TerrainAnalysis.__wrap(ret[0]);
    }
    /**
     * Map height in tiles (0 if the map has no readable terrain).
     * @returns {number}
     */
    get heightTiles() {
        const ret = wasm.maprenderer_heightTiles(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Renders the zero-asset minimap and encodes it as a PNG.
     * @param {string} options
     * @returns {Uint8Array}
     */
    minimapPng(options) {
        const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_minimapPng(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Renders the zero-asset minimap to RGBA pixels. Needs no assets at all; if round 1's
     * `.dat` tables happen to be loaded they refine dot sizing and melee filtering.
     * @param {string} options
     * @returns {RenderedImage}
     */
    minimapRgba(options) {
        const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_minimapRgba(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return RenderedImage.__wrap(ret[0]);
    }
    /**
     * Parses a `.scm`/`.scx` map file (MPQ + CHK).
     * @param {Uint8Array} map_bytes
     */
    constructor(map_bytes) {
        const ptr0 = passArray8ToWasm0(map_bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        MapRendererFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Builds the render plan (the decide/draw split — see `broodmap-render`'s `plan` module)
     * as JSON, for external executors like a GPU renderer. Requires round 1's assets.
     * @param {string} options
     * @returns {string}
     */
    planJson(options) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.maprenderer_planJson(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Renders the map preview and encodes it as a PNG.
     * @param {string} options
     * @returns {Uint8Array}
     */
    renderPng(options) {
        const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_renderPng(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Renders the map preview to RGBA pixels.
     * @param {string} options
     * @returns {RenderedImage}
     */
    renderRgba(options) {
        const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_renderRgba(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return RenderedImage.__wrap(ret[0]);
    }
    /**
     * The CV5 and VF4 paths, in that order. Fetch these and pass their bytes to
     * `analyzeTerrain`; they do not need to be registered with `addAsset`.
     * @returns {string[]}
     */
    requiredAnalysisAssets() {
        const ret = wasm.maprenderer_requiredAnalysisAssets(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Round 1 of the prefetch: the CASC paths of the base assets (tileset tables + `.dat`
     * tables) this map needs under `options`. Fetch and [`add_asset`](Self::add_asset) all of
     * them before calling [`required_graphics`](Self::required_graphics).
     * @param {string} options
     * @returns {string[]}
     */
    requiredAssets(options) {
        const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_requiredAssets(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v2;
    }
    /**
     * Round 2 of the prefetch: the CASC paths of the art assets (anims, SD canvas GRPs) the
     * map's units and sprites need under `options`. Requires round 1's tables to already be
     * added. A path that fails to fetch can simply be skipped — that one drawable degrades,
     * the render still succeeds.
     * @param {string} options
     * @returns {string[]}
     */
    requiredGraphics(options) {
        const ptr0 = passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.maprenderer_requiredGraphics(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v2;
    }
    /**
     * CV5, VF4, and units.dat, in that order, for `analyzeMap`.
     * @returns {string[]}
     */
    requiredMapAnalysisAssets() {
        const ret = wasm.maprenderer_requiredMapAnalysisAssets(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Map width in tiles (0 if the map has no readable terrain).
     * @returns {number}
     */
    get widthTiles() {
        const ret = wasm.maprenderer_widthTiles(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) MapRenderer.prototype[Symbol.dispose] = MapRenderer.prototype.free;

/**
 * An immutable region result detached from its source [`TerrainAnalysis`] snapshot.
 *
 * Labels are row-major 8-pixel walk cells. Zero denotes blocked terrain; positive labels are
 * one-based region IDs. Passages describe one representative connection per adjacent region pair.
 */
export class RegionSnapshot {
    static __wrap(ptr) {
        const obj = Object.create(RegionSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        RegionSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RegionSnapshotFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_regionsnapshot_free(ptr, 0);
    }
    /**
     * Returns an independently owned row-major `Uint32Array` of region labels.
     *
     * Zero is blocked terrain; region IDs begin at one and correspond to `metadataJson` entries.
     * @returns {Uint32Array}
     */
    labels() {
        const ret = wasm.regionsnapshot_labels(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Serializes compact region and passage metadata, without duplicating the full label buffer.
     * @returns {string}
     */
    metadataJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.regionsnapshot_metadataJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
}
if (Symbol.dispose) RegionSnapshot.prototype[Symbol.dispose] = RegionSnapshot.prototype.free;

/**
 * A rendered RGBA image, ready for `new ImageData(new Uint8ClampedArray(data), width, height)`.
 */
export class RenderedImage {
    static __wrap(ptr) {
        const obj = Object.create(RenderedImage.prototype);
        obj.__wbg_ptr = ptr;
        RenderedImageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RenderedImageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_renderedimage_free(ptr, 0);
    }
    /**
     * The RGBA8 pixels, row-major (copies out of WASM memory).
     * @returns {Uint8Array}
     */
    get data() {
        const ret = wasm.renderedimage_data(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {number}
     */
    get height() {
        const ret = wasm.renderedimage_height(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Non-fatal notes about things the render skipped.
     * @returns {string[]}
     */
    get warnings() {
        const ret = wasm.renderedimage_warnings(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get width() {
        const ret = wasm.renderedimage_width(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) RenderedImage.prototype[Symbol.dispose] = RenderedImage.prototype.free;

/**
 * An 8-pixel point-movement snapshot, optionally including initial static melee obstacles.
 * Moving units and mover size are not represented. This does not certify engine pathing or walls.
 */
export class TerrainAnalysis {
    static __wrap(ptr) {
        const obj = Object.create(TerrainAnalysis.prototype);
        obj.__wbg_ptr = ptr;
        TerrainAnalysisFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TerrainAnalysisFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_terrainanalysis_free(ptr, 0);
    }
    /**
     * Computes clearance-derived regions for the currently active terrain/obstacle grid.
     *
     * `minProminencePixels` must be from 8 through 4096. An omitted
     * `minRelativeProminencePercent` uses the core default of 40; supplied values must be from 0
     * through 100. The returned result owns its labels and metadata, so it remains valid after
     * this analysis snapshot is freed or its obstacle toggle changes. Regions are a static
     * square-clearance graph, not unit-fit or engine pathing data.
     * @param {number} min_prominence_pixels
     * @param {number | null} [min_relative_prominence_percent]
     * @returns {RegionSnapshot}
     */
    analyzeRegions(min_prominence_pixels, min_relative_prominence_percent) {
        const ret = wasm.terrainanalysis_analyzeRegions(this.__wbg_ptr, min_prominence_pixels, !isLikeNone(min_relative_prominence_percent), isLikeNone(min_relative_prominence_percent) ? 0 : min_relative_prominence_percent);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return RegionSnapshot.__wrap(ret[0]);
    }
    /**
     * Ground and air distances between the selected candidates' near-center walk anchors.
     * Respects the current obstacle toggle. Hypothetical depots are not added as obstacles.
     * Disconnected bases return null ground distance; undiscovered/out-of-range IDs are errors.
     * @param {number} start_id
     * @param {number} end_id
     * @returns {string}
     */
    baseRouteJson(start_id, end_id) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.terrainanalysis_baseRouteJson(this.__wbg_ptr, start_id, end_id);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Starts reusable map-wide analysis from JSON [{id,routeAnchor:[walkX,walkY]|null}].
     * At most 256 unique IDs and 32KiB JSON. Uses terrain alone, independent of obstacle mode.
     * A missing routeAnchor is skipped like null. Advance between event-loop yields;
     * completion is required for results.
     * @param {string} bases_json
     * @param {number | null} [min_widening_percent]
     * @returns {BaseTopologyJob}
     */
    beginBaseTopology(bases_json, min_widening_percent) {
        const ptr0 = passStringToWasm0(bases_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.terrainanalysis_beginBaseTopology(this.__wbg_ptr, ptr0, len0, !isLikeNone(min_widening_percent), isLikeNone(min_widening_percent) ? 0 : min_widening_percent);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BaseTopologyJob.__wrap(ret[0]);
    }
    /**
     * Row-major bytes: bit 0 walkable, bit 1 CV5 terrain-buildability hint,
     * bit 2 ramp, bits 3..4 minitile elevation (0..2), bit 5 terrain cell obstructed by a
     * static map object (retained even when objects are ignored). Bit 0 respects the current
     * obstacle toggle. Buildability excludes occupancy,
     * footprint, creep/power, resources, and other placement restrictions.
     * @returns {Uint8Array}
     */
    cellFlags() {
        const ret = wasm.terrainanalysis_cellFlags(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Check proposed building rectangles and mover passage in an explicitly bounded pixel window.
     * Uses original terrain plus exact static object rectangles when the obstacle toggle is enabled.
     * Static placement checks omit race rules, power, creep, resource spacing, and dynamic state.
     * A blocked result is local to this window and model, not a certified game wall.
     * @param {string} query_json
     * @returns {string}
     */
    checkWallJson(query_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(query_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.terrainanalysis_checkWallJson(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Row-major logical-pixel radii of empty, axis-aligned squares centered on walk cells.
     * Blocked cells are zero; walkable cells adjacent to a blocker or map edge are 4px.
     * Values follow the obstacle toggle and include the map boundary. This is a square
     * (Chebyshev) distance measure of the raster, not Euclidean distance, corridor width,
     * or proof that a StarCraft unit can pass. The returned buffer is independently owned.
     * @returns {Uint16Array}
     */
    clearancePixels() {
        const ret = wasm.terrainanalysis_clearancePixels(this.__wbg_ptr);
        var v1 = getArrayU16FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 2, 2);
        return v1;
    }
    /**
     * Batches up to 256 terrain-only entrance surveys without rebuilding the immutable terrain
     * preparation. Input is JSON `[[[startX,startY],[endX,endY]], ...]` with strict unsigned
     * integer coordinates and a 32 KiB limit. Results preserve input order and use the same
     * objects returned by `entrancesJson`. Aggregate route output is capped at 2,097,152 points.
     * These limits do not bound CPU time: each distinct origin can require a full-grid search.
     * Callers needing responsive cancellation should submit smaller origin groups and yield
     * between synchronous calls. An empty batch returns `[]` without preparing a survey.
     * @param {string} queries_json
     * @param {number | null} [min_widening_percent]
     * @returns {string}
     */
    entrancesBatchJson(queries_json, min_widening_percent) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(queries_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.terrainanalysis_entrancesBatchJson(this.__wbg_ptr, ptr0, len0, !isLikeNone(min_widening_percent), isLikeNone(min_widening_percent) ? 0 : min_widening_percent);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Finds local width transitions along a clearance-favoring route from start to end.
     *
     * Coordinates are 8-pixel walk cells. This always surveys terrain alone, regardless of the
     * obstacle toggle: resources and neutral objects do not define geological entrances.
     * `minWideningPercent` defaults to 25 and accepts integral values from 0 through 200.
     * Candidate centers lie within the first 1024 logical pixels; profiles may look 192px farther.
     * `outwardSampleCount` is 3 normally, or 2 when a late turn excludes the +160px sample.
     * Cross-section endpoints in the JSON are logical pixels; route points are walk cells. Spans
     * are raster approximations, not certified chokepoints, construction legality, unit fit, or
     * shortest movement routes.
     * @param {number} start_x
     * @param {number} start_y
     * @param {number} end_x
     * @param {number} end_y
     * @param {number | null} [min_widening_percent]
     * @returns {string}
     */
    entrancesJson(start_x, start_y, end_x, end_y, min_widening_percent) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.terrainanalysis_entrancesJson(this.__wbg_ptr, start_x, start_y, end_x, end_y, !isLikeNone(min_widening_percent), isLikeNone(min_widening_percent) ? 0 : min_widening_percent);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Discovers and caches resource-base candidates in a snapshot made by `analyzeMap`.
     * Options: `{depotWidthTiles:4,depotHeightTiles:3,maxMineralBlockerAmount:8}`.
     * Set maxMineralBlockerAmount to null to disallow clearing; unknown amounts never qualify.
     * allowDestructibleClearing and allowStartObstacleClearing default to true.
     * requiredObstacles lists overlapping buildings requiring destruction; startClearedObstacles
     * lists overlaps removed automatically if that exact start is occupied (including invincible ones).
     * Candidate requiredMinerals lists direct placement prerequisites. All objects remain
     * blockers for current route queries; routeAnchor is null if the whole depot area is blocked.
     * IDs are zero-based in top-to-bottom, left-to-right depot order. Discovery always uses
     * the initial static obstacles, independently of the route toggle. This is a heuristic:
     * stock resource IDs, no creep/power or complete placement rules, and no main/natural roles.
     * Unknown options and unsupported inputs fail without replacing the last successful catalog.
     * @param {string} options_json
     * @returns {string}
     */
    findBasesJson(options_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(options_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.terrainanalysis_findBasesJson(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get heightWalkTiles() {
        const ret = wasm.terrainanalysis_heightWalkTiles(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Number of static obstacle rectangles identified in this snapshot.
     * @returns {number}
     */
    get obstacleCount() {
        const ret = wasm.terrainanalysis_obstacleCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Partitions terrain alone using up to 256 finite pixel-coordinate spans.
     *
     * Input is JSON `[[[x1,y1],[x2,y2]], ...]`, at most 32 KiB; coordinates must be
     * nonnegative integers within inclusive map edges, and each span must have distinct ends.
     * An empty list returns ordinary terrain components. This does not mutate routing,
     * the base catalog, or obstacle mode, and does not validate wall placement.
     * @param {string} spans_json
     * @returns {AreaSnapshot}
     */
    partitionAreas(spans_json) {
        const ptr0 = passStringToWasm0(spans_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.terrainanalysis_partitionAreas(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AreaSnapshot.__wrap(ret[0]);
    }
    /**
     * Two wall-contact spans at the ends of each recognized terrain ramp.
     *
     * Always uses the original terrain, independent of obstacle mode. Positions are walk cells;
     * span endpoints and widths are logical pixels. These are elevation/ramp-flag observations,
     * not route-local widening claims or certified movement/building-placement boundaries.
     * @returns {string}
     */
    rampsJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.terrainanalysis_rampsJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Routes between 8-pixel cell centers. Both endpoints must be walkable; they are
     * never silently moved. Points include both endpoints. Disconnected endpoints return
     * an empty point list and null groundDistancePixels. Distances use logical pixels,
     * independent of preview resolution. Ground costs are 8 / 11.312 pixels per step
     * (fixed-point octile approximation), with no diagonal corner cutting.
     * @param {number} start_x
     * @param {number} start_y
     * @param {number} end_x
     * @param {number} end_y
     * @returns {string}
     */
    routeJson(start_x, start_y, end_x, end_y) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.terrainanalysis_routeJson(this.__wbg_ptr, start_x, start_y, end_x, end_y);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Choose object-aware routing or the original terrain-only model. Turning this off
     * ignores every obstacle, including invincible buildings; it does not simulate removal.
     * @param {boolean} enabled
     */
    setObstaclesEnabled(enabled) {
        wasm.terrainanalysis_setObstaclesEnabled(this.__wbg_ptr, enabled);
    }
    /**
     * Starts a bounded, resumable search for static wall layouts. Construction prepares terrain
     * and candidates synchronously, so its bounded preprocessing can still occupy one event-loop turn.
     * The job snapshots the selected
     * terrain/obstacle model, so later obstacle-toggle changes do not affect it.
     * @param {string} query_json
     * @returns {WallSearchJob}
     */
    startWallSearch(query_json) {
        const ptr0 = passStringToWasm0(query_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.terrainanalysis_startWallSearch(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WallSearchJob.__wrap(ret[0]);
    }
    /**
     * Chooses collision-safe walk-cell-center endpoints around a selected entrance. Search query
     * start/end are placeholders here; the explicit entrance controls the direction.
     * @param {string} query_json
     * @param {string} entrance_json
     * @returns {string}
     */
    suggestWallEndpointsJson(query_json, entrance_json) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(query_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(entrance_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.terrainanalysis_suggestWallEndpointsJson(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Returns terrain-only walk-cell connectivity reachable from an entrance near a bounded
     * pixel window. The result is local to the returned rectangle and ignores objects,
     * buildability, and terrain height.
     * @param {string} input_json
     * @returns {string}
     */
    wallPlacementReachJson(input_json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.terrainanalysis_wallPlacementReachJson(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Conventional melee palette with dimensions from the caller's units.dat. Empty for terrain-only snapshots.
     * @returns {string}
     */
    wallProfilesJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.terrainanalysis_wallProfilesJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get widthWalkTiles() {
        const ret = wasm.terrainanalysis_widthWalkTiles(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) TerrainAnalysis.prototype[Symbol.dispose] = TerrainAnalysis.prototype.free;

/**
 * Incremental bounded wall search. It owns the core search snapshot, so it can safely outlive
 * its TerrainAnalysis creator. Dropping/freeing it abandons unfinished work.
 */
export class WallSearchJob {
    static __wrap(ptr) {
        const obj = Object.create(WallSearchJob.prototype);
        obj.__wbg_ptr = ptr;
        WallSearchJobFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WallSearchJobFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wallsearchjob_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get exploredStates() {
        const ret = wasm.wallsearchjob_exploredStates(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get layoutCount() {
        const ret = wasm.wallsearchjob_layoutCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Serializes the completed result. Calling this before a terminal step is an error so callers
     * do not accidentally copy route data while reporting progress.
     * @returns {string}
     */
    resultJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wallsearchjob_resultJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Advances at most 16 search states. Call between browser event-loop yields.
     * Returns true when a terminal result is available.
     * @param {number} max_states
     * @returns {boolean}
     */
    step(max_states) {
        const ret = wasm.wallsearchjob_step(this.__wbg_ptr, max_states);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
}
if (Symbol.dispose) WallSearchJob.prototype[Symbol.dispose] = WallSearchJob.prototype.free;

/**
 * Summarizes a map file's scenario as JSON (see the README for the fields). `options` is an
 * optional JSON object raising (or lowering) broodmap's default resource limits:
 * `{ "maxMapBytes", "maxMpqFileBytes", "maxChkBytes", "maxMergedChunkBytes" }`. Fails if the file
 * isn't a readable map within those limits, or lacks the scenario name, player or force sections
 * every playable map has.
 * @param {Uint8Array} map_bytes
 * @param {string | null} [options]
 * @returns {string}
 */
export function summarizeMapJson(map_bytes, options) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passArray8ToWasm0(map_bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(options) ? 0 : passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.summarizeMapJson(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_throw_344f42d3211c4765: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./broodmap_wasm_bg.js": import0,
    };
}

const AreaSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_areasnapshot_free(ptr, 1));
const BaseTopologyJobFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_basetopologyjob_free(ptr, 1));
const MapRendererFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_maprenderer_free(ptr, 1));
const RegionSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_regionsnapshot_free(ptr, 1));
const RenderedImageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_renderedimage_free(ptr, 1));
const TerrainAnalysisFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_terrainanalysis_free(ptr, 1));
const WallSearchJobFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wallsearchjob_free(ptr, 1));

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU16FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint16ArrayMemory0().subarray(ptr / 2, ptr / 2 + len);
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint16ArrayMemory0 = null;
function getUint16ArrayMemory0() {
    if (cachedUint16ArrayMemory0 === null || cachedUint16ArrayMemory0.byteLength === 0) {
        cachedUint16ArrayMemory0 = new Uint16Array(wasm.memory.buffer);
    }
    return cachedUint16ArrayMemory0;
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint16ArrayMemory0 = null;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('broodmap_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
